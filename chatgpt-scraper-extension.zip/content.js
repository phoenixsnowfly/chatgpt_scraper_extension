//此插件由Threads@phoenixsnowfly 與 ChatGPT 共同完成，若需使用請@原作者且標註，感謝!

// 🛡️ 防止重複綁定 listener
if (!window.__chatgpt_scraper_initialized__) {
  window.__chatgpt_scraper_initialized__ = true;
  console.log("✅ ChatGPT Scraper 已初始化");

  // 等待訊息區載入完成
  function waitForMessages(timeout = 10000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();

      function check() {
        const messages = document.querySelectorAll('[data-message-author-role]');
        if (messages.length > 0) {
          resolve(messages);
        } else if (Date.now() - startTime > timeout) {
          reject("⏳ 超時：未偵測到對話訊息");
        } else {
          requestAnimationFrame(check);
        }
      }

      check();
    });
  }

  // 抽取訊息內容
  function extractChatMessages() {
    const messageNodes = document.querySelectorAll('[data-message-author-role]');
    const content = [];

    messageNodes.forEach((node, i) => {
      const role = node.getAttribute("data-message-author-role"); // "user" or "assistant"
      const textEl = node.querySelector(".markdown") || node.querySelector("p") || node;
      const text = textEl?.innerText?.trim();
      if (text) {
        content.push(`[${role.toUpperCase()} #${i + 1}]\n${text}`);
      }
    });

    return content.join("\n\n---\n\n");
  }

  // 下載為 .txt 檔
  function downloadAsTextFile(content) {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    a.href = url;
    a.download = `ChatGPT_Export_${timestamp}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // 接收 popup.js 傳來的訊息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape_and_download") {
      waitForMessages()
        .then(() => {
          const result = extractChatMessages();
          if (result.length > 0) {
            downloadAsTextFile(result);
            sendResponse({ status: "completed" });
          } else {
            sendResponse({ status: "no_data" });
          }
        })
        .catch((err) => {
          console.warn("❌ 抓取失敗:", err);
          sendResponse({ status: "timeout" });
        });

      return true; // async callback
    }
  });
}
