document.getElementById("scrapeBtn").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id || (!tab.url.includes("chat.openai.com") && !tab.url.includes("chatgpt.com"))) {
      document.getElementById("status").textContent = "❌ 請切換到 ChatGPT 對話頁面 (支援 chatgpt.com)";
      return;
    }

    // 注入 content.js
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });

    chrome.tabs.sendMessage(tab.id, { action: "scrape_and_download" }, (response) => {
      const status = document.getElementById("status");

      if (chrome.runtime.lastError) {
        console.error("傳送失敗:", chrome.runtime.lastError.message);
        status.textContent = "⚠️ 無法注入內容腳本，請確認權限";
      } else if (response?.status === "completed") {
        status.textContent = "✅ 匯出成功！";
      } else {
        status.textContent = "⚠️ 抓取失敗或無內容";
      }
    });

  } catch (err) {
    console.error("❌ 發生錯誤：", err);
    document.getElementById("status").textContent = "❌ 執行失敗";
  }
});

//此插件由Threads@phoenixsnowfly 與 ChatGPT共同完成，若需使用請@原作者且標註，感謝!