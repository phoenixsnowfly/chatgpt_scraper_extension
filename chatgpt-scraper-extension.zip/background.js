chrome.runtime.onInstalled.addListener(() => {
  console.log("ChatGPT Scraper Extension Installed 🛰️");
});

//此插件由Threads@phoenixsnowfly 與 ChatGPT 共同完成，若需使用請@原作者且標註，感謝!